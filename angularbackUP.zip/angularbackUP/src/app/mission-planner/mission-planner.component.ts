import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mission-planner',
  templateUrl: './mission-planner.component.html',
  styleUrls: ['./mission-planner.component.css']
})
export class MissionPlannerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
