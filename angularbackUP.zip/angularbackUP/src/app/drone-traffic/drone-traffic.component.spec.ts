import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DroneTrafficComponent } from './drone-traffic.component';

describe('DroneTrafficComponent', () => {
  let component: DroneTrafficComponent;
  let fixture: ComponentFixture<DroneTrafficComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DroneTrafficComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DroneTrafficComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
