import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LiveCameraFeedComponent } from './live-camera-feed.component';

describe('LiveCameraFeedComponent', () => {
  let component: LiveCameraFeedComponent;
  let fixture: ComponentFixture<LiveCameraFeedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LiveCameraFeedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LiveCameraFeedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
