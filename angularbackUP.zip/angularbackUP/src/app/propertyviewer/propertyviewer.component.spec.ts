import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PropertyviewerComponent } from './propertyviewer.component';

describe('PropertyviewerComponent', () => {
  let component: PropertyviewerComponent;
  let fixture: ComponentFixture<PropertyviewerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PropertyviewerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PropertyviewerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
