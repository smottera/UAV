import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { FaqComponent } from './faq/faq.component';
import { LoginComponent } from './login/login.component';
import { ReqSurveyComponent } from './req-survey/req-survey.component';
import { SearchComponent } from './search/search.component';
import { SoftwareComponent } from './software/software.component';
import { HomeComponent } from './home/home.component';
import { CustomersComponent } from './customers/customers.component';
import { RndComponent } from './rnd/rnd.component';

const routes: Routes = [
  {
    path: '', 
    component: HomeComponent
  },
  {
  path: 'login' , 
  component: LoginComponent
},
{
  path: 'dashboard', 
  component: DashboardComponent
},
{
  path: 'software', 
  component: SoftwareComponent
},
{
  path: 'customers', 
  component: CustomersComponent
},
{
  path: 'rnd', 
  component: RndComponent
},
{
  path: 'faq', 
  component: FaqComponent
}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
