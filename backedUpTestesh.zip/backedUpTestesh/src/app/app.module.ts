import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CockpitComponent } from './cockpit/cockpit.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { SearchComponent } from './search/search.component';
import { LoginComponent } from './login/login.component';
import { ConnectionInfoComponent } from './connection-info/connection-info.component';
import { PropertyviewerComponent } from './propertyviewer/propertyviewer.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ReqSurveyComponent } from './req-survey/req-survey.component';
import { FaqComponent } from './faq/faq.component';
import { DroneTrafficComponent } from './drone-traffic/drone-traffic.component';
import { GaugesComponent } from './gauges/gauges.component';
import { ControlsComponent } from './controls/controls.component';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatCardModule } from '@angular/material/card';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatButtonModule } from '@angular/material/button';
import { MatMenuModule } from '@angular/material/menu';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatTabsModule } from '@angular/material/tabs';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatDividerModule } from '@angular/material/divider';
import { MatListModule } from '@angular/material/list';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatSliderModule } from '@angular/material/slider';

import { MissionPlannerComponent } from './mission-planner/mission-planner.component';
import { LiveCameraFeedComponent } from './live-camera-feed/live-camera-feed.component';
import { HomeComponent } from './home/home.component';
import { CustomersComponent } from './customers/customers.component';
import { SoftwareComponent } from './software/software.component';
import { RndComponent } from './rnd/rnd.component';
import { GmapsComponent } from './gmaps/gmaps.component';
import { AboutComponent } from './about/about.component';
//import { GoogleMapsModule } from '@angular/google-maps';



@NgModule({
  declarations: [
    AppComponent,
    CockpitComponent,
    HeaderComponent,
    FooterComponent,
    SearchComponent,
    LoginComponent,
    PropertyviewerComponent,
    DashboardComponent,
    ReqSurveyComponent,
    FaqComponent,
    DroneTrafficComponent,
    ConnectionInfoComponent,
    GaugesComponent,
    ControlsComponent,
    MissionPlannerComponent,
    LiveCameraFeedComponent,
    HomeComponent,
    CustomersComponent,
    SoftwareComponent,
    RndComponent,
    GmapsComponent,
    AboutComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatCardModule,
    MatButtonModule,
    MatAutocompleteModule,
    MatMenuModule,
    MatTabsModule,
    MatFormFieldModule,
    MatInputModule,
    MatRadioModule,
    MatTableModule,
    MatPaginatorModule,
    MatDividerModule,
    MatListModule,
    MatGridListModule,
    MatButtonToggleModule,
    MatSliderModule,
    MatExpansionModule
   // GoogleMapsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
