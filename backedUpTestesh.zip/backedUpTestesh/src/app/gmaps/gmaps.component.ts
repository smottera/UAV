import { Component, AfterViewInit, ViewChild } from '@angular/core';
//import {} from '@types/googlemaps';

declare const google: any;

@Component({
  selector: 'app-gmaps',
  templateUrl: './gmaps.component.html',
  styleUrls: ['./gmaps.component.css']
})

export class GmapsComponent implements AfterViewInit {

  @ViewChild('map') mapElement: any;

  constructor() { }

  // map: google.maps.Map;

  ngAfterViewInit(): void {
    const mapProperties = {
      center: new google.maps.LatLng(-33.86682, 151.20732),
      zoom: 15,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    const map = new google.maps.Map(this.mapElement.nativeElement, mapProperties);
  }
  
}
