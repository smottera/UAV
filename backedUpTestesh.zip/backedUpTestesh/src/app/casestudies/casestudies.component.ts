import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-casestudies',
  templateUrl: './casestudies.component.html',
  styleUrls: ['./casestudies.component.css']
})
export class CasestudiesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
