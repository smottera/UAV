import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-propertyviewer',
  templateUrl: './propertyviewer.component.html',
  styleUrls: ['./propertyviewer.component.css']
})
export class PropertyviewerComponent implements OnInit {


  formatLabel(value: number) {
    if (value >= 1000) {
      return Math.round(value / 1000) + 'k';
    }

    return value;
  }

  constructor() { }

  ngOnInit(): void {
  }

}
