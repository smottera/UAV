import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReqSurveyComponent } from './req-survey.component';

describe('ReqSurveyComponent', () => {
  let component: ReqSurveyComponent;
  let fixture: ComponentFixture<ReqSurveyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReqSurveyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReqSurveyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
