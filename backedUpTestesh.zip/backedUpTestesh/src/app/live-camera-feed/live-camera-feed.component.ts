import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-live-camera-feed',
  templateUrl: './live-camera-feed.component.html',
  styleUrls: ['./live-camera-feed.component.css']
})
export class LiveCameraFeedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
